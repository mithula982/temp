import React from 'react';
import {Text, View} from 'react-native';

function HistorySellingpoint(props) {
  return (
    <View>
      <Text> Selling Point </Text>
    </View>
  );
}

export default HistorySellingpoint;
