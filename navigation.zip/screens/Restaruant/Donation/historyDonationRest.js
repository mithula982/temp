import React from 'react';
import {Text, View} from 'react-native';

function HistoryDonationRest(props) {
  return (
    <View>
      <Text> Selling Donation </Text>
    </View>
  );
}

export default HistoryDonationRest;
