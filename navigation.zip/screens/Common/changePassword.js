import React from 'react';
import {Text, View} from 'react-native';

function ChangePassword(props) {
  return (
    <View>
      <Text> Edit Profile</Text>
    </View>
  );
}

export default ChangePassword;
