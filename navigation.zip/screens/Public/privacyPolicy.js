import React from 'react';
import {Text, View} from 'react-native';

function PrivacyPolicy(props) {
  return (
    <View>
      <Text>Privacy Policy</Text>
    </View>
  );
}

export default PrivacyPolicy;
