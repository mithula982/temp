import React from 'react';
import {Text, View} from 'react-native';

const sellingPoints = () => {
  return (
    <View>
      <Text> Selling Points </Text>
    </View>
  );
};

export default sellingPoints;
