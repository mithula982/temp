import React from 'react';
import {Text, View} from 'react-native';

function TermsCondition(props) {
  return (
    <View>
      <Text>Terms Condition</Text>
    </View>
  );
}

export default TermsCondition;
