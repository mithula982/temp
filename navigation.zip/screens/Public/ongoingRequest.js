import React from 'react';
import {Text, View} from 'react-native';

function OngoingRequest(props) {
  return (
    <View>
      <Text>  Ongoing Request </Text>
    </View>
  );
}

export default OngoingRequest;
