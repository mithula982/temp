import React from 'react';
import {Text, View} from 'react-native';

const collectionPoints = () => {
  return (
    <View>
      <Text> Collection Points </Text>
    </View>
  );
};

export default collectionPoints;
