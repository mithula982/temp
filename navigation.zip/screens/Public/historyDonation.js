import React from 'react';
import { Text, View } from 'react-native';

function HistoryDonation(props) {
    return (
<View>
    <Text> Donation </Text>
</View>
    );
}

export default HistoryDonation;