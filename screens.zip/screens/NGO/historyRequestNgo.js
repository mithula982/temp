import React from 'react';
import {Text, View} from 'react-native';

function HistoryRequestNgo(props) {
  return (
    <View>
      <Text> NGO Request  </Text>
    </View>
  );
}

export default HistoryRequestNgo;
