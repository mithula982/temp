import React from 'react';
import {Text, View} from 'react-native';

function AboutUs(props) {
  return (
    <View>
      <Text> About Us</Text>
    </View>
  );
}

export default AboutUs;
