import React from 'react';
import {Text, View} from 'react-native';

function HistoryRequestHome(props) {
  return (
    <View>
      <Text> Home Request </Text>
    </View>
  );
}

export default HistoryRequestHome;
